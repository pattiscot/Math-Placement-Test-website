# Math-Placement-Test-website
Website containing directions for our math placement test



Hello. You are receiving this email because you have either expressed interest in the upcoming math placement exam or took the exam back in August and may want to try again. The exam is scheduled for December 5th at 2pm and will take place in Hickman Science Center room 1303. The exam should take around 90 minutes. If you have not registered for the exam on Aleks.com please do so as soon as possible so that you have time to study the material before the test. You must take the practice test prior to the scheduled date for the placement exam or you will not be able to take the placement exam. If you took the test in August no further action is needed on your part. Feel free to show up to take the placement exam if you wish. 

If you have any questions about the exam or need help registering for it, please e-mail me (or stop by my office) and I will be glad to help! Good luck and have a wonderful Thanksgiving break!

Heck

